DS LABORATORY PRACTICAL - ALL PROGRAMS (Python 3)

Run any file:   python GA1_library_borrowing.py
Every program is MENU-DRIVEN and has sample data built in.

GA1  GA1_library_borrowing.py           Average, highest/lowest, zero-borrowers, mode + complexities
GA2  GA2_linear_binary_search.py        Linear + Binary search (iterative & recursive)
GA3  GA3_selection_bubble_sort.py       Selection + Bubble sort, top 5 salaries
GB4  GB4_stack_undo_redo.py             Stack: change / undo / redo / display
GB5  GB5_queue_event_processing.py      Queue: add / process / display / cancel
GB6  GB6_linkedlist_student_records.py  Linked list: add/delete/update/search/sort/display
GC7  GC7_hash_chaining.py               Hash table size 10, key % 10, chaining
GC8  GC8_hash_linear_probing.py         Hash table, key % size, linear probing
GD9  GD9_bfs_dfs.py                     BFS (adj list) + DFS (adj matrix)
GD10 GD10_binary_search_tree.py         BST insert/delete/search/display

EXAM TIPS
- Be ready to explain: why binary search needs a sorted list; FIFO vs LIFO;
  why DFS uses a stack/recursion and BFS a queue; the 3 BST delete cases;
  what a collision is and why we use a DELETED marker in linear probing.
- Type the code yourself in the exam - don't just copy; examiners ask questions.
